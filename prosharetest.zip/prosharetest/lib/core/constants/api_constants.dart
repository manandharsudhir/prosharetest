class ApiConstants {
  static const String baseurl = 'https://api.openweathermap.org/';
  static const String imageUrl = 'https://openweathermap.org/img/wn/';
  static const String getWeather = 'data/2.5/forecast';
  static const String getLatLng = 'geo/1.0/direct';
}
