// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'city_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_CityResponseModel _$$_CityResponseModelFromJson(Map<String, dynamic> json) =>
    _$_CityResponseModel(
      name: json['name'] as String,
      lat: (json['lat'] as num).toDouble(),
      lon: (json['lon'] as num).toDouble(),
    );

Map<String, dynamic> _$$_CityResponseModelToJson(
        _$_CityResponseModel instance) =>
    <String, dynamic>{
      'name': instance.name,
      'lat': instance.lat,
      'lon': instance.lon,
    };

_$_LocalNames _$$_LocalNamesFromJson(Map<String, dynamic> json) =>
    _$_LocalNames();

Map<String, dynamic> _$$_LocalNamesToJson(_$_LocalNames instance) =>
    <String, dynamic>{};
