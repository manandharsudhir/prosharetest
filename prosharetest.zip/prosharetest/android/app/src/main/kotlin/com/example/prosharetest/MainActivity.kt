package com.example.prosharetest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
